<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Meeting extends Model
{
    protected $table = 'meetings';
    protected static $tbl = 'meetings';
    protected $primaryKey = 'meeting_id';

    protected $fillable = array(
        'meeting_id',
        'title',
        'location',
        'employer_id',
        'candidate_id',
        'start_date_time',
        'end_date_time',
        'reminder',
        'description',
    );

    static function getEmployer($id){
        $emp = Employer::where('employer_id',$id)->first();
        if($emp){
            return $emp->first_name.' '.$emp->last_name;
        }else{
            return "Not Found";
        }
    }
    static function getCandidate($id){
        $emp = Candidate::where('candidate_id',$id)->first();
        if($emp){
            return $emp->first_name.' '.$emp->last_name;
        }else{
            return "Not Found";
        }
    }
    static function getPriority($priority){
        if($priority==5){
            return 'Highest';
        }elseif ($priority==4){
            return 'High';
        }elseif ($priority==3){
            return 'Normal';
        }elseif ($priority==2){
            return 'Low';
        }elseif ($priority==1){
            return 'Lowest';
        }else{
            return 'Error';
        }
    }
    static function MeetingHasCandidate($meeting_id,$candidate_id): bool
    {
        $sql = DB::table('meeting_candidates')
            ->where('meeting_id',$meeting_id)
            ->where('candidate_id',$candidate_id)->get()->count();
        if($sql){
            return true;
        }
        return false;
    }
    static function myMeetingResponse($meeting_id,$candidate_id){
        $data = DB::table('meeting_candidates')
            ->where('candidate_id',$candidate_id)
            ->where('meeting_id',$meeting_id)
            ->first();
        if($data){
            return $data->response;
        }
        return "Pending";
    }
}
