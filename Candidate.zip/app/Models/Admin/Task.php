<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Task extends Model
{
    protected $table = 'tasks';
    protected static $tbl = 'tasks';
    protected $primaryKey = 'task_id';

    protected $fillable = array(
        'task_id',
        'title',
        'due_date',
        'employer_id',
        'candidate_id',
        'status',
        'priority',
        'reminder',
        'description',
        'response',
    );

    static function getEmployer($id){
        $emp = Employer::where('employer_id',$id)->first();
        if($emp){
            return $emp->first_name.' '.$emp->last_name;
        }else{
            return "Not Found";
        }
    }
    static function getCandidate($id){
        $emp = Candidate::where('candidate_id',$id)->first();
        if($emp){
            return $emp->first_name.' '.$emp->last_name;
        }else{
            return "Not Found";
        }
    }
    static function getPriority($priority){
        if($priority==5){
            return 'Highest';
        }elseif ($priority==4){
            return 'High';
        }elseif ($priority==3){
            return 'Normal';
        }elseif ($priority==2){
            return 'Low';
        }elseif ($priority==1){
            return 'Lowest';
        }else{
            return 'Error';
        }
    }
}
