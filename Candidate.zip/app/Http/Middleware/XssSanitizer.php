<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class XssSanitizer
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $inputs = $request->all();

        // Remove HTML tags from all input values except for 'description'
        array_walk_recursive($inputs, function(&$value, $key) {
            if ($key !== 'description') {
                $value = strip_tags($value);
            }
        });

        $request->replace($inputs);
        return $next($request);
    }
}
