<?php

namespace App\Http\Controllers;

use App\Helpers\DbTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class GetController extends Controller
{
    public function getCandidateForEmployee($id){

        $candidates = DB::select(
            'SELECT c.candidate_id,c.first_name,c.last_name FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$id.' GROUP BY c.candidate_id');
        return response()->json($candidates);
    }
    public function migrate(){

    }
}
