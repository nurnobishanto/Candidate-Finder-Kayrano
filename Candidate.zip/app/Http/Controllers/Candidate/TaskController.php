<?php

namespace App\Http\Controllers\Candidate;

use App\Http\Controllers\Controller;
use App\Models\Admin\Task;
use App\Models\Front\Candidate as FrontCandidate;
use App\Models\Front\Quiz;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function listView()
    {
        $candidate = FrontCandidate::getFirst('candidates.candidate_id', candidateSession());
        $tasks = Task::where('candidate_id',$candidate['candidate_id'])->get();
        $data['page_title'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['tasks'] = $tasks;
        return view('front'.viewPrfx().'candidates.task-listing', $data);
    }
    public function singleView($task_id){
        $task = Task::where('task_id',$task_id)->first();
        $data['page_title'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['task'] = $task;
        return view('front'.viewPrfx().'candidates.task', $data);
    }
    public function update(Request $request,$task_id){
        $request->validate([
            'status'=>'required',
        ]);
        $task = Task::where('task_id',$task_id)->first();
        $task->update($request->all());
        return redirect()->back();
    }


}
