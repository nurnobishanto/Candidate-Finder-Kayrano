<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use App\Models\Admin\Task;
use App\Models\Admin\Employer;
use App\Rules\MinString;
use App\Rules\MaxString;
use App\Rules\MaxFile;

class TasksController extends Controller
{
    /**
     * View Function to display tasks list view page
     *
     * @return html/string
     */
    public function index()
    {
        $candidates = DB::select(
            'SELECT c.candidate_id,ec.employer_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id GROUP BY c.candidate_id ');
        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['tasks'] = Task::orderBy('created_at','DESC')->get();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = $candidates;

        return view('admin.tasks.list', $data);
    }
    public function create(Request $request){
        $request->validate([
            'title' => 'required',
            'due_date'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'status'=>'required',
            'priority'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Task::create($request->all());
        return redirect()->back();
    }
    public function edit($task_id){
        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['task'] = Task::where('task_id',$task_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();
        return view('admin.tasks.edit', $data);
    }
    public function show($task_id){
        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['task'] = Task::where('task_id',$task_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();
        return view('admin.tasks.show', $data);
    }

    public function update(Request $request,$task_id){
        $request->validate([
            'title' => 'required',
            'due_date'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'status'=>'required',
            'priority'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Task::where('task_id',$task_id)->first()->update($request->all());
        return redirect()->back();
    }
    public function delete($task_id){
        Task::where('task_id',$task_id)->first()->delete();
        return redirect()->back();
    }



}
