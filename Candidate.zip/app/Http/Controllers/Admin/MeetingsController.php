<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use App\Models\Admin\Meeting;
use App\Models\Admin\Employer;
use App\Rules\MinString;
use App\Rules\MaxString;
use App\Rules\MaxFile;

class MeetingsController extends Controller
{

    public function index()
    {
        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meetings'] = Meeting::orderBy('created_at','DESC')->get();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();

        return view('admin.meetings.list', $data);
    }
    public function create(Request $request){
        $request->validate([
            'title' => 'required',
            'location'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'start_date_time'=>'required',
            'end_date_time'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);

        $m = Meeting::create([
            'title' => $request->title,
            'location'=>$request->location,
            'employer_id'=>$request->employer_id,
            'start_date_time'=>$request->start_date_time,
            'end_date_time'=>$request->end_date_time,
            'reminder'=>$request->reminder,
            'description'=>$request->description,
        ]);

        foreach ($request->candidate_id as $c){
            DB::select('INSERT INTO db_meeting_candidates (meeting_id, candidate_id, response) VALUES ('.$m->meeting_id.','.$c.',"Pending")');
        }
        return redirect()->back();
    }
    public function edit($meeting_id){
        $candidates = DB::select(
            'SELECT c.candidate_id,c.first_name,c.last_name,mc.response FROM db_candidates as c JOIN db_meeting_candidates as mc
                      WHERE c.candidate_id = mc.candidate_id AND mc.meeting_id = '.$meeting_id.' GROUP BY c.candidate_id');

        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meeting'] = Meeting::where('meeting_id',$meeting_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = $candidates;
        return view('admin.meetings.edit', $data);
    }
    public function show($meeting_id){
        $candidates = DB::select(
            'SELECT c.candidate_id,c.first_name,c.last_name,mc.response FROM db_candidates as c JOIN db_meeting_candidates as mc
                      WHERE c.candidate_id = mc.candidate_id AND mc.meeting_id = '.$meeting_id.' GROUP BY c.candidate_id');

        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meeting'] = Meeting::where('meeting_id',$meeting_id)->first();
        $data['candidates'] = $candidates;
        return view('admin.meetings.show', $data);
    }

    public function update(Request $request,$meeting_id){
        $request->validate([
            'title' => 'required',
            'location'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'start_date_time'=>'required',
            'end_date_time'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        DB::select('DELETE FROM db_meeting_candidates WHERE meeting_id = '.$meeting_id);

        foreach ($request->candidate_id as $c){
            DB::select('INSERT INTO db_meeting_candidates (meeting_id, candidate_id, response) VALUES ('.$meeting_id.','.$c.',"Pending")');
        }
        Meeting::where('meeting_id',$meeting_id)->first()->update([
            'title' => $request->title,
            'location'=>$request->location,
            'employer_id'=>$request->employer_id,
            'start_date_time'=>$request->start_date_time,
            'end_date_time'=>$request->end_date_time,
            'reminder'=>$request->reminder,
            'description'=>$request->description,
        ]);
        return redirect()->back();
    }
    public function delete($meeting_id){
        Meeting::where('meeting_id',$meeting_id)->first()->delete();
        return redirect()->back();
    }



}
