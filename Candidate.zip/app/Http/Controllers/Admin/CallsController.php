<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use App\Models\Admin\Call;
use App\Models\Admin\Employer;
use App\Rules\MinString;
use App\Rules\MaxString;
use App\Rules\MaxFile;

class CallsController extends Controller
{
    /**
     * View Function to display calls list view page
     *
     * @return html/string
     */
    public function index()
    {
        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['calls'] = Call::orderBy('created_at','DESC')->get();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();

        return view('admin.calls.list', $data);
    }
    public function create(Request $request){
        $request->validate([
            'topic' => 'required',
            'call_type'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'date'=>'required',
            'time'=>'required',
            'purpose'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Call::create($request->all());
        return redirect()->back();
    }
    public function edit($call_id){
        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['call'] = Call::where('call_id',$call_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();
        return view('admin.calls.edit', $data);
    }
    public function show($call_id){
        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['call'] = Call::where('call_id',$call_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();
        return view('admin.calls.show', $data);
    }

    public function update(Request $request,$call_id){
        $request->validate([
            'topic' => 'required',
            'call_type'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'date'=>'required',
            'time'=>'required',
            'purpose'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Call::where('call_id',$call_id)->first()->update($request->all());
        return redirect()->back();
    }
    public function delete($call_id){
        Call::where('call_id',$call_id)->first()->delete();
        return redirect()->back();
    }



}
