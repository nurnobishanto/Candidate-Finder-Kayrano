<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Admin\Meeting;
use App\Models\Front\Candidate as FrontCandidate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MeetingController extends Controller
{
    public function listView()
    {
        $candidate = FrontCandidate::getFirst('candidates.candidate_id', candidateSession());
        $meetings = DB::select('SELECT * FROM db_meetings AS m JOIN db_meeting_candidates AS mc WHERE mc.meeting_id = m.meeting_id AND mc.candidate_id = '.$candidate['candidate_id']);
        $data['page_title'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meetings'] = $meetings;
        $data['candidate_id'] = $candidate['candidate_id'];
        return view('front'.viewPrfx().'candidates.meeting-listing', $data);
    }
    public function singleView($meeting_id){
        $candidates = DB::select(
            'SELECT c.candidate_id,c.first_name,c.last_name,mc.response FROM db_candidates as c JOIN db_meeting_candidates as mc
                      WHERE c.candidate_id = mc.candidate_id AND mc.meeting_id = '.$meeting_id.' GROUP BY c.candidate_id');
        $candidate = FrontCandidate::getFirst('candidates.candidate_id', candidateSession());
        $myResponse = Meeting::myMeetingResponse($meeting_id,$candidate['candidate_id']);
        $meeting = Meeting::where('meeting_id',$meeting_id)->first();
        $data['page_title'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meeting'] = $meeting;
        $data['candidates'] = $candidates;
        $data['myResponse'] = $myResponse;
        return view('front'.viewPrfx().'candidates.meeting', $data);
    }
    public function update(Request $request,$meeting_id){
        $candidate = FrontCandidate::getFirst('candidates.candidate_id', candidateSession());
        DB::table('meeting_candidates')
            ->where('candidate_id',$candidate['candidate_id'])
            ->where('meeting_id',$meeting_id)
            ->update([
                'response'=>$request->response,
            ]);
        return redirect()->back();
    }
}
