<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Admin\Call;
use App\Models\Front\Candidate as FrontCandidate;
use Illuminate\Http\Request;

class CallController extends Controller
{
    public function listView()
    {
        $candidate = FrontCandidate::getFirst('candidates.candidate_id', candidateSession());
        $calls = Call::where('candidate_id',$candidate['candidate_id'])->get();
        $data['page_title'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['calls'] = $calls;
        return view('front'.viewPrfx().'candidates.call-listing', $data);
    }
    public function singleView($call_id){
        $call = Call::where('call_id',$call_id)->first();
        $data['page_title'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['call'] = $call;
        return view('front'.viewPrfx().'candidates.call', $data);
    }
    public function update(Request $request,$call_id){

        $call = Call::where('call_id',$call_id)->first();
        $call->update($request->all());
        return redirect()->back();
    }
}
