<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use App\Models\Admin\Employer;
use App\Models\Admin\Call;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CallController extends Controller
{
    public function index()
    {
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'
            ].' GROUP BY c.candidate_id');
        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['calls'] = Call::where('employer_id',$emp['employer_id'])->orderBy('created_at','DESC')->get();
        $data['employer'] = $emp;
        $data['candidates'] = $candidates;

        return view('employer.calls.list', $data);
    }
    public function create(Request $request){

        $request->validate([
            'topic' => 'required',
            'call_type'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'date'=>'required',
            'time'=>'required',
            'purpose'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);

        Call::create($request->all());
        return redirect()->back();
    }
    public function show($call_id){

        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['call'] = Call::where('call_id',$call_id)->first();
        $data['candidates'] = Candidate::orderBy('created_at','DESC')->get();
        return view('employer.calls.show', $data);
    }
    public function edit($call_id){
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'
            ].' GROUP BY c.candidate_id');
        $data['page'] = __('message.calls');
        $data['menu'] = 'calls';
        $data['call'] = Call::where('call_id',$call_id)->first();
        $data['employer'] = $emp;
        $data['candidates'] = $candidates;
        return view('employer.calls.edit', $data);
    }
    public function update(Request $request,$call_id){
        $request->validate([
            'topic' => 'required',
            'call_type'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'date'=>'required',
            'time'=>'required',
            'purpose'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Call::where('call_id',$call_id)->first()->update($request->all());
        return redirect()->route('employer-calls');
    }
    public function delete($call_id){
        Call::where('call_id',$call_id)->first()->delete();
        return redirect()->back();
    }

}
