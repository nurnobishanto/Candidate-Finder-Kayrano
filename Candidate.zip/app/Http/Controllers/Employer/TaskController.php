<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use App\Models\Admin\Employer;
use App\Models\Admin\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TaskController extends Controller
{
    public function index()
    {
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'].' GROUP BY c.candidate_id'
        );

        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['tasks'] = Task::where('employer_id',$emp['employer_id'])->orderBy('created_at','DESC')->get();
        $data['employer'] = $emp;
        $data['candidates'] = $candidates;

        return view('employer.tasks.list', $data);
    }
    public function create(Request $request){

        $request->validate([
            'title' => 'required',
            'due_date'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'status'=>'required',
            'priority'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);

        Task::create($request->all());
        return redirect()->back();
    }
    public function show($task_id){
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'].' GROUP BY c.candidate_id');
        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['task'] = Task::where('task_id',$task_id)->first();
        $data['employers'] = Employer::orderBy('created_at','DESC')->get();
        $data['candidates'] = $candidates;

        return view('employer.tasks.show', $data);
    }
    public function edit($task_id){
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'].' GROUP BY c.candidate_id'
        );
        $data['page'] = __('message.tasks');
        $data['menu'] = 'tasks';
        $data['task'] = Task::where('task_id',$task_id)->first();
        $data['employer'] = $emp;
        $data['candidates'] = $candidates;

        return view('employer.tasks.edit', $data);
    }
    public function update(Request $request,$task_id){
        $request->validate([
            'title' => 'required',
            'due_date'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'status'=>'required',
            'priority'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        Task::where('task_id',$task_id)->first()->update($request->all());
        return redirect()->route('employer-tasks');
    }
    public function delete($task_id){
        Task::where('task_id',$task_id)->first()->delete();
        return redirect()->back();
    }

}
