<?php

namespace App\Http\Controllers\Employer;

use App\Http\Controllers\Controller;
use App\Models\Admin\Candidate;
use App\Models\Admin\Employer;
use App\Models\Admin\Meeting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MeetingController extends Controller
{
    public function index()
    {
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'
            ].' GROUP BY c.candidate_id');

        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meetings'] = Meeting::where('employer_id',$emp['employer_id'])->orderBy('created_at','DESC')->get();
        $data['employer_id'] = $emp['employer_id'];
        $data['candidates'] = $candidates;


        return view('employer.meetings.list', $data);
    }
    public function create(Request $request){

        $request->validate([
            'title' => 'required',
            'location'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'start_date_time'=>'required',
            'end_date_time'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);

        $m = Meeting::create([
            'title' => $request->title,
            'location'=>$request->location,
            'employer_id'=>$request->employer_id,
            'start_date_time'=>$request->start_date_time,
            'end_date_time'=>$request->end_date_time,
            'reminder'=>$request->reminder,
            'description'=>$request->description,
        ]);

        foreach ($request->candidate_id as $c){
            DB::select('INSERT INTO db_meeting_candidates (meeting_id, candidate_id, response) VALUES ('.$m->meeting_id.','.$c.',"Pending")');
        }
        return redirect()->back();
    }
    public function show($meeting_id){
        $candidates = DB::select(
            'SELECT c.candidate_id,c.first_name,c.last_name,mc.response FROM db_candidates as c JOIN db_meeting_candidates as mc
                      WHERE c.candidate_id = mc.candidate_id AND mc.meeting_id = '.$meeting_id.' GROUP BY c.candidate_id');
        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meeting'] = Meeting::where('meeting_id',$meeting_id)->first();
        $data['candidates'] = $candidates;
        return view('employer.meetings.show', $data);
    }
    public function edit($meeting_id){
        $emp = objToArr(\App\Models\Employer\Employer::getEmployer('employers.employer_id', encode(employerSession())));
        $candidates = DB::select(
            'SELECT c.candidate_id FROM db_candidates as c JOIN db_employer_candidates as ec
                      WHERE c.candidate_id = ec.candidate_id AND ec.employer_id = '.$emp['employer_id'
            ].' GROUP BY c.candidate_id');
        $data['page'] = __('message.meetings');
        $data['menu'] = 'meetings';
        $data['meeting'] = Meeting::where('meeting_id',$meeting_id)->first();
        $data['employer'] = $emp;
        $data['candidates'] = $candidates;
        return view('employer.meetings.edit', $data);
    }
    public function update(Request $request,$meeting_id){
        $request->validate([
            'title' => 'required',
            'location'=>'required',
            'employer_id'=>'required',
            'candidate_id'=>'required',
            'start_date_time'=>'required',
            'end_date_time'=>'required',
            'reminder'=>'required',
            'description'=>'required',
        ]);
        DB::select('DELETE FROM db_meeting_candidates WHERE meeting_id = '.$meeting_id);

        foreach ($request->candidate_id as $c){
            DB::select('INSERT INTO db_meeting_candidates (meeting_id, candidate_id, response) VALUES ('.$meeting_id.','.$c.',"Pending")');
        }
        Meeting::where('meeting_id',$meeting_id)->first()->update([
            'title' => $request->title,
            'location'=>$request->location,
            'employer_id'=>$request->employer_id,
            'start_date_time'=>$request->start_date_time,
            'end_date_time'=>$request->end_date_time,
            'reminder'=>$request->reminder,
            'description'=>$request->description,
        ]);
        return redirect()->route('employer-meetings');
    }
    public function delete($meeting_id){
        Meeting::where('meeting_id',$meeting_id)->first()->delete();
        return redirect()->back();
    }

}
