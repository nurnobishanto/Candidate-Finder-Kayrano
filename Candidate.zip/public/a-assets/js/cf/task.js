function Task() {

    "use strict";

    var self = this;

    this.initFilters = function () {
        $("#status, #employer_id").off();
        $("#status, #employer_id").change(function () {
            self.initTasksDatatable();
        });
        $('.select2').select2();
    };

    this.initTasksDatatable = function () {
        $('#tasks_datatable').DataTable({
            "aaSorting": [[ 3, 'desc' ]],
            "columnDefs": [{"orderable": false, "targets": [0,1,5]}],
            "lengthMenu": [[10, 25, 50, 100000000], [10, 25, 50, "All"]],
            "searchDelay": 2000,
            "processing": true,
            "serverSide": true,
            "ajax": {
                "type": "POST",
                "url": application.url+'/admin/tasks/data',
                "data": function ( d ) {
                    d.status = $('#status').val();
                    d.employer_id = $('#employer_id').val();
                    d._token = application._token;
                },
                "complete": function (response) {
                    self.initiCheck();
                    self.initAllCheck();
                    self.initTaskCreateOrEditForm();
                    self.initTaskChangeStatus();
                    self.initTaskDelete();
                    //$('.table-bordered').parent().attr('style', 'overflow:auto'); //For responsive
                },
            },
            'paging': true,
            'lengthChange': true,
            'searching': true,
            'info': true,
            'autoWidth': true,
            'destroy':true,
            'stateSave': true
        });
    };

    this.initTaskSave = function () {
        application.onSubmit('#admin_task_create_update_form', function (result) {
            application.showLoader('admin_task_create_update_form_button');
            application.post('/admin/tasks/save', '#admin_task_create_update_form', function (res) {
                var result = JSON.parse(application.response);
                if (result.success === 'true') {
                    $('#modal-default').modal('hide');
                    self.initTasksDatatable();

                    //For job create or edit
                    if (!isEmpty(result.data)) {
                        var data = {id: result.data.id, text: result.data.title};
                        var newOption = new Option(data.text, data.id, false, false);
                        $('#tasks').append(newOption).trigger('change');
                    }
                } else {
                    application.hideLoader('admin_task_create_update_form_button');
                    application.showMessages(result.messages, 'admin_task_create_update_form .modal-body');
                }
            });
        });
    };

    this.initTaskCreateOrEditForm = function () {
        $('.create-or-edit-task').off();
        $('.create-or-edit-task').on('click', function () {
            var modal = '#modal-default';
            var id = $(this).data('id');
            id = id ? '/'+id : '';
            var modal_title = id ? lang['edit_task'] : lang['create_task'];
            $(modal).modal('show');
            $(modal+' .modal-title').html(modal_title);
            application.load('/admin/tasks/create-or-edit'+id, modal+' .modal-body-container', function (result) {
                self.initTaskSave();
                $('.dropify').dropify();
            });
        });
    };

    this.initTaskChangeStatus = function () {
        $('.change-task-status').off();
        $('.change-task-status').on('click', function () {
            var button = $(this);
            var id = $(this).data('id');
            var status = parseInt($(this).data('status'));
            button.html("<i class='fa fa-spin fa-spinner'></i>");
            button.attr("disabled", true);
            application.load('/admin/tasks/status/'+id+'/'+status, '', function (result) {
                button.removeClass('btn-success');
                button.removeClass('btn-danger');
                button.addClass(status === 1 ? 'btn-danger' : 'btn-success');
                button.html(status === 1 ? lang['inactive'] : lang['active']);
                button.data('status', status === 1 ? 0 : 1);
                button.attr("disabled", false);
                button.attr("title", status === 1 ? lang['click_to_activate'] : lang['click_to_deactivate']);
            });
        });
    };

    this.initAllCheck = function () {
        $('input.all-check').on('ifChecked', function(event){
            $('input.single-check').iCheck('check');
        });
        $('input.all-check').on('ifUnchecked', function(event){
            $('input.single-check').iCheck('uncheck');
        });
    };

    this.initTaskDelete = function () {
        $('.delete-task').off();
        $('.delete-task').on('click', function () {
            var status = confirm(lang['are_u_sure']);
            var id = $(this).data('id');
            if (status === true) {
                application.load('/admin/tasks/delete/'+id, '', function (result) {
                    self.initTasksDatatable();
                });
            }
        });
    };

    this.initTasksListBulkActions = function () {
        $('.bulk-action').off();
        $('.bulk-action').on('click', function (e) {
            e.preventDefault();
            var ids = [];
            var action = $(this).data('action');
            $('.single-check').each(function (i, v) {
                if ($(this).is(':checked')) {
                    ids.push($(this).data('id'))
                }
            });
            if (ids.length === 0) {
                alert(lang['please_select_some_records_first']);
                $('.bulk-action').val('');
                return false;
            } else {
                application.post('/admin/tasks/bulk-action', {ids:ids, action: $(this).data('action')}, function (result) {
                    $('.bulk-action').val('');
                    $('.all-check').prop('checked', false);
                    self.initTasksDatatable();
                });
            }
        });
    };

    this.initiCheck = function () {
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass   : 'iradio_minimal-blue'
        });
    };

}

$(document).ready(function() {
    var task = new Task();
    task.initFilters();
    task.initTasksListBulkActions();
    task.initTasksDatatable();
});
